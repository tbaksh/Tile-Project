import java.util.ArrayList;
import processing.core.PApplet;

//Inherit from Tile and implement drawing randomly sized and located
//spots on our tile
class RandomSpotter extends Tile
{
	// Helper class.  You can have your own, if needed. 
	// This one holds all the info necessary to place a circle
	// the screen. This is an example of a nested class.  That's 
	// why it doesn't have to be in its own file -- it can only
	// be used inside RandomSpotter.
	class Spot {

		public int x ;
		public int y ;
		public int theColor ;
		public int diameter ;

		public Spot( int pX, int pY, int pColor, int pDiameter  )
		{
			x = pX ;
			y = pY ;
			diameter = pDiameter ;
			theColor = pColor ;
		}
	} ;
	
	// ArrayLists are covered in zyBook 2.12
	ArrayList<Spot> spots = new ArrayList <Spot> ( ) ;
	int nSpots = 0 ;
	final static int maxSpots = 500 ;

	RandomSpotter ( PApplet pSketch, int pX, int pY, int pSize )
	{
		super( pSketch, pX, pY, pSize ) ;
	}

	// Uses an ArrayList as a queue, keeping maxSpots in the array
	// at all times.  Then draws the spots on the Tile.
	void animate ( int nReps ) 
	{
		// Make sure we stay inside our tile
		clipGraphics ( ) ;
		
		// Pick random location for the spot
		int x = ( int ) theSketch.random( ( float ) size ) ;
		int y = ( int ) theSketch.random( ( float ) size ) ;
	
		// Could also generate and use a random color here
		int theColor = theSketch.color( 255,0,0 ) ;
		
		// New spot at x,y with random size (up to 30 pixels)
		Spot spot = new Spot ( x, y, theColor, (int)( theSketch.random ( 30 ) ) ) ;
		
		// Put it in the ArrayList (aka Queue)
		spots.add( spot ) ;
		nSpots ++ ;

		// More than maxSpots spots showing? Blank out oldest.
		if(nSpots > maxSpots )
		{
			Spot tmp = spots.remove(0) ;  // remove oldest element
			
			// cover it with black
			theSketch.fill ( 0 ) ;
			theSketch.ellipse( tmp.x, tmp.y, tmp.diameter, tmp.diameter );
			nSpots -- ;
		}
		// enhanced for loop is in zyBooks 8.1
		for( Spot s : spots )
		{
			theSketch.fill( s.theColor ) ;
			theSketch.ellipse( s.x, s.y, s.diameter, s.diameter ) ;
		}
	}
}