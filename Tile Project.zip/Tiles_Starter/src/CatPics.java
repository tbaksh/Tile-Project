import processing.core.PApplet;
import processing.core.PImage;


class CatPics extends Tile 
{
	private boolean flip = true ;
	private PImage img1 ;
	private PImage img2 ;

	CatPics ( ) 
	{
	}

	
	CatPics ( PApplet pSketch, int pX, int pY, int pSize  )
	{
		super( pSketch, pX, pY, pSize ) ;  // Invoke Tile constructor
		
		
		img1 = theSketch.loadImage("data/EA.jpg");  
		img2 = theSketch.loadImage( "data/H&M.jpeg") ;
	}

	
	void blank ( )
	{
		clipGraphics ( ) ;
		theSketch.fill ( 0 ) ;
		theSketch.rect( xloc, yloc, size, size ) ;
	}

	
	void animate ( int nReps )
	{
		
		clipGraphics ( ) ;
		
		if( flip )
		{
			theSketch.image(img1, xloc, yloc, size, size);
			flip = false ;
		}
		else
		{
			theSketch.image(img2, xloc, yloc, size, size);
			flip = true ;
		}
		
		
		killTime ( 800 ) ;
	}
}


	