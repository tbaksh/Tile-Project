
import processing.core.PApplet;

// a lot about abstract classes is in Chapter 13 of your zyBook.
// that is optional work, but I think it will definitely help in this 
// project.  I will give credit for chapter 13 if you do it (but I will not
// take off any credit if you do not -- it is optional). 
public abstract class Tile 
{
	protected int xloc ;
	protected int yloc ;
	protected int size ;
	protected PApplet theSketch ; ;

	// X and Y define the upper left corner of your tile
	// size defines how big (use 300) and we assume square (300x300)
	Tile( PApplet parentSketch, int pX, int pY, int pSize ) 
	{
		xloc = pX ;
		yloc = pY ;
		size = pSize ;
		theSketch = parentSketch ;
	}

	Tile ( )
	{
	}

	// Code you supply in this method must do something visual (and hopefully cool)
	// to change the appearance of your tile.  Do whatever it is nRepeats times.  Code
	// in such a way that execution will not linger in your tile too long -- this code:
	// for( int i = 0 ; i < 1000000 ; i++ ) { blah-blah } would be a bad idea, for instance.
	void animate ( int nRepeats )
	{
	}

	// Code making your entire tile black here.
	void blank ( )
	{
	}

	// Kill some time to slow things down in your Tile.  Use sparingly
	// since this slows everyone down
	void killTime ( int millis )
	{
		int startTime = theSketch.millis ( ) ;
		int endTime = startTime + millis ;
		while( theSketch.millis( ) < endTime ) ;
	}

	// Always call this as the first method in your animate ( ) method.
	// This ensures that your graphics will stay in the tile. 
	void clipGraphics( )
	{
		theSketch.clip(xloc, yloc, size, size);
	}
} ;
