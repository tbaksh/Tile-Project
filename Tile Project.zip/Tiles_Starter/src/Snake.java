import java.util.ArrayList;
import processing.core.PApplet;

//Inherit from Tile and implement drawing randomly sized and located
//spots on our tile
class Snake extends Tile {
	int originX;
	int originY;

	enum Direction {
		LEFT, RIGHT, UP, DOWN
	}

	Direction direction = null;
	
	Snake(){
		
	}

	// Helper class. Contains information to place a square on the screen
	class Square {

		public int x;
		public int y;
		public int theColor;
		public int size;

		//constructor that sets the location, color and size of the square
		//uses the built in rect processing function
		public Square(int pX, int pY, int pColor, int pSize) {
			x = pX;
			y = pY;
			size = pSize;
			theColor = pColor;
			theSketch.fill(theColor);
			theSketch.rect(x, y, size, size);
		}
	}

	//creates a list to store the squares being created
	ArrayList<Square> squares = new ArrayList<Square>();
	int nSquares = 0;
	//establishes a baseline size for the square if no size is used in the constructor
	int squareSize = 10;

	//basic constructor for the Snake class (same as previous tiles)
	Snake(PApplet pSketch, int pX, int pY, int pSize) {
		super(pSketch, pX, pY, pSize);
		originX = pX;
		originY = pY;
	}

	//overloaded constructor that allows the size to be changed
	Snake(PApplet pSketch, int pX, int pY, int pSize, int bSize) {
		super(pSketch, pX, pY, pSize);
		originX = pX;
		originY = pY;
		squareSize = bSize;
	}

	void animate(int nReps) {
		clipGraphics();

		int x = 0;
		int y = 0;
		int theColor = 0;

		//when the program starts and after it resets this statement runs
		//sets a random color and location to start based on the top left corner of the tile
		//the expression ensures that the snake starts no more than 1/4 of the size from the border
		if (squares.isEmpty() == true) {
			x = originX + (int) (theSketch.random(size) / 2 + size / 4);
			y = originY + (int) (theSketch.random(size) / 2 + size / 4);
			theColor = theSketch.color(theSketch.random(255), theSketch.random(255), theSketch.random(255));
		} 
		
		//after the initial square is set this statement runs
		//a random number from 1-4 is selected to determine the direction to put the next square
		//1 - up, 2 - right, 3 - down, 4 - left
		//each time the program runs it assigns a new value of x and y by adding the size of the square in the desired direction
		//the if statement ensures that the snake does not backtrack and end itself ie. cannot go up then down
		//this means that there is about a 50% chance it will keep going in the same direction and 50% chance it will turn
		else {
			int rand = ((int) theSketch.random(4)) + 1;

			switch (rand) {

			case (1):
				if (direction == Direction.DOWN) {
					y = (squares.get(nSquares - 1).y) + squareSize;
					x = (squares.get(nSquares - 1).x);
					direction = Direction.DOWN;

				} else {
					y = (squares.get(nSquares - 1).y) - squareSize;
					x = (squares.get(nSquares - 1).x);
					direction = Direction.UP;
				}
				break;
			case (2):
				if (direction == Direction.LEFT) {
					y = (squares.get(nSquares - 1).y);
					x = (squares.get(nSquares - 1).x) - squareSize;
					direction = Direction.LEFT;
				} else {
					y = (squares.get(nSquares - 1).y);
					x = (squares.get(nSquares - 1).x) + squareSize;
					direction = Direction.RIGHT;
				}
				break;
			case (3):
				if (direction == Direction.UP) {
					y = (squares.get(nSquares - 1).y) - squareSize;
					x = (squares.get(nSquares - 1).x);
					direction = Direction.UP;
				} else {
					y = (squares.get(nSquares - 1).y) + squareSize;
					x = (squares.get(nSquares - 1).x);
					direction = Direction.DOWN;
				}
				break;
			case (4):
				if (direction == Direction.RIGHT) {
					y = (squares.get(nSquares - 1).y);
					x = (squares.get(nSquares - 1).x) + squareSize;
					direction = Direction.RIGHT;
				} else {
					y = (squares.get(nSquares - 1).y);
					x = (squares.get(nSquares - 1).x) - squareSize;
					direction = Direction.LEFT;
				}
				break;
			}

			//the color of the square stays the same as the color of the previous square
			theColor = squares.get(nSquares - 1).theColor;
		}
		
		//each time the program runs it creates a new instance of the square in the selected location and color
		//the size remains unchanged after the initial call of the snake object
		Square square = new Square(x, y, theColor, squareSize);

		//the square is added to the ArrayList and nSquares keep track of the number of squares that have been added
		squares.add(square);
		nSquares++;

		//if any square has the same x and y location as a previous square the snake "resets"
		//the arraylist is cleared and a black square the size of the tile is placed to "clear the board"
		for (int i = 0; i < nSquares - 1; i++) {
			if (squares.get(i).x == squares.get(nSquares - 1).x && squares.get(i).y == squares.get(nSquares - 1).y) {
				squares.clear();

				theSketch.fill(0);
				theSketch.rect(originX, originY, 300, 300);
				nSquares = 0;
			}
		}
		
		//if the square ever goes beyond the size of the the tile the snake also "resets"
		if (x > originX + 300 || x < originX || y > originY + 300 || y < originY || nSquares > 150) {
			squares.clear();

			theSketch.fill(0);
			theSketch.rect(originX, originY, 300, 300);
			nSquares = 0;
		}

	}

}