import processing.core.PApplet;
import processing.core.PImage;

class EA extends Tile 
{
	private boolean flip = false ;
	private PImage img1 ;
	//private PImage img2 ;

	EA ( ) 
	{
	}

	
	EA ( PApplet pSketch, int pX, int pY, int pSize  )
	{
		super( pSketch, pX, pY, pSize ) ;  
		
		
		img1 = theSketch.loadImage("data/EA.jpg"); 
		//img2 = theSketch.loadImage("data/H&M.jpeg") ;
	}

	
	void blank ( )
	{
		clipGraphics ( ) ;
		theSketch.fill ( 0 ) ;
		theSketch.rect( xloc, yloc, size, size ) ;
	}

	
	void animate ( int nReps )
	{
		
		clipGraphics ( ) ;
		
		if( flip )
		{
			theSketch.image(img1, xloc, yloc, size, size);
			flip = false ;
		}
		else
		{
			//theSketch.image(img2, xloc, yloc, size, size);
			flip = false ;
		}
		
		
		killTime ( 0 ) ;
	}
} ;



