// Lots of general info about this approach is here:
// http://happycoding.io/tutorials/java/processing-in-java
// and here:
// https://processing.org/tutorials/eclipse/

import processing.core.PApplet;

public class TestTiles extends PApplet {
	
	// Our tiles
	CatPics cats ;
	RandomSpotter spots ;
	EA EA ;
	HM HM;
	Snake Snake;
	Star Star;
	Alchemy Alchemy;
	
	

	public static void main(String[] args) {
        PApplet.main("TestTiles");
    }
	
	// Processing's in it method, runs before setup ( ) or draw ( )
	public void settings() {
		  size(900, 600);
	}
	
	// One time initialization here
	public void setup ( )
	{
	  background (0, 0, 0);
	  fill (255, 255, 0);
	  
	  //println ( dataPath( "" ) ) ;
	  //println ( sketchPath( "" )) ;
	  
	  // Instantiate each Tile
	  // "this" refers to the current PApplet so the tiles
	  // can access methods of Processing (from core.jar)
	  // When you create your tile, you will instantiate it here.
	  cats = new CatPics ( this, 300, 300, 300 ) ;
	  spots = new RandomSpotter ( this, 0, 0, 300 ) ;
	  EA = new EA (this, 0, 600, 300);
	  HM = new HM (this, 600, 0, 300);
	  Snake = new Snake (this, 300, 5, 300);
	  Star = new Star (this, 600, 300, 300);
	  Alchemy = new Alchemy (this, 300, 600, 300);
	  }

	

	// This is the Processing event loop
	public void draw ( )
	{
		size(900, 600);

	  // Animate the tiles
	  cats.animate ( 1 ) ;
	  spots.animate( 1 ) ;
	  EA.animate(1);
	  HM.animate(1);
	  Snake.animate(1);
	  Star.animate(1);
	  Alchemy.animate(1);
	  }
}
